﻿namespace NerdStore.Core.Messages
{
    public class AtualizarItemPedidoCommand : Command
    {

    }
}
