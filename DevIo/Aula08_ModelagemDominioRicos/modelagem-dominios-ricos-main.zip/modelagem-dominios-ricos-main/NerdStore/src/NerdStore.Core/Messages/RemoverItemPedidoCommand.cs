﻿namespace NerdStore.Core.Messages
{
    public class RemoverItemPedidoCommand : Command
    {

    }
}
