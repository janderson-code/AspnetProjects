﻿namespace NerdStore.Core.Messages
{
    public class AplicarVoucherPedidoCommand : Command
    {

    }
}
