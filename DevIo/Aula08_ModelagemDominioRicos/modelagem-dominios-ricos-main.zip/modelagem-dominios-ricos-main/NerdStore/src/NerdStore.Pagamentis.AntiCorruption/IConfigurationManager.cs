﻿namespace NerdStore.Pagamentos.AntiCorruption;

public interface IConfigurationManager
{
    string GetValue(string node);
}
