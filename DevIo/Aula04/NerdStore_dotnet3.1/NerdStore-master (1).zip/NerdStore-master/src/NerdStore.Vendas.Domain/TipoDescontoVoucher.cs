﻿namespace NerdStore.Vendas.Domain
{
    public enum TipoDescontoVoucher
    {
        Porcentagem = 0,
        Valor = 1
    }
}