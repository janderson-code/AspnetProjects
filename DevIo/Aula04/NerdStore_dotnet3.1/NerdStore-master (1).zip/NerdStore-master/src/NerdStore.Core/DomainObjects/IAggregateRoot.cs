﻿namespace NerdStore.Core.DomainObjects
{
    public interface IAggregateRoot
    {
    }
}