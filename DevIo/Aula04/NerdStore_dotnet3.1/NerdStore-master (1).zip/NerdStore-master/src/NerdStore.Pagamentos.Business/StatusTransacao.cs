﻿namespace NerdStore.Pagamentos.Business
{
    public enum StatusTransacao
    {
        Pago = 1,
        Recusado = 2
    }
}