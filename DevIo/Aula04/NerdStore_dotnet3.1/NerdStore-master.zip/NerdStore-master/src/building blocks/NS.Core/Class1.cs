﻿using System;

namespace NS.Core
{
    public class Class1
    {
    }
}
