﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NS.WebApp.MVC.Extensions
{
    public class AppSettings
    {
        public string AutenticacaoUrl { get; set; }
        public string CatalogoUrl { get; set; }
    }
}
