﻿namespace DungeonFinderWebApp.Infra
{
    public class Class1
    {

    }
}