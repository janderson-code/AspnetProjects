USE[DungeonFinder]

INSERT INTO Usuario (email, password, DataCadastro) 
VALUES ('gustavo@email.com', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92', GETDATE())

INSERT INTO Usuario (email, password, DataCadastro) 
VALUES ('janderson@email.com', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92', GETDATE())

INSERT INTO Usuario (email, password, DataCadastro) 
VALUES ('antonio@email.com', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92', GETDATE())

INSERT INTO Usuario (email, password, DataCadastro) 
VALUES ('marcos@email.com', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92', GETDATE())