



UPDATE Jogador SET idUsuario = 1
where idJogador = 1

UPDATE Jogador SET idUsuario = 2
where idJogador = 2

UPDATE Jogador SET idUsuario = 3
where idJogador = 3

UPDATE Jogador SET idUsuario = 4
where idJogador = 4