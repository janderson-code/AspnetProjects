﻿namespace DungeonFinderDomain.Model.Requests
{
    public class MesaRequest
    {
        public string Sistema { get; set; }
        public string Nome { get; set; }
        public int IdMesa { get; set; }
        public int isAtivo { get; set; }
    }
}
