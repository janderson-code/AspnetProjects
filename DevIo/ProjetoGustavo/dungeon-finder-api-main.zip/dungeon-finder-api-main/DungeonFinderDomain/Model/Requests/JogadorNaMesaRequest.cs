﻿

namespace DungeonFinderDomain.Model.Requests
{
    public class JogadorNaMesaRequest
    {

        public int idJogador { get; set; }
        public int idMesa { get; set; }
    }
}
