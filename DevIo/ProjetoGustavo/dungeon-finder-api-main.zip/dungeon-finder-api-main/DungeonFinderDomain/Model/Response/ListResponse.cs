﻿namespace DungeonFinderDomain.Model.Response
{
    public class ListResponse<T> : BaseResponse 
    {
        public List<T> Items;
  
    }
}
