﻿namespace DungeonFinderDomain.Model.Entities
{
    public class Sistema
    {
        public int IdSistema { get; set; }
        public string Nome { get; set; }
        public DateTime DataCriacao { get; set; }
    }
}
