﻿namespace DungeonFinderDomain.Model.Entities
{
    public class Jogador
    {
        public int IdJogador { get; set; }
        public int IdUsuario { get; set; }
        public string Nome { get; set; }
    }
}
